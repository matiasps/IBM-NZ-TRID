--queries x day 
select extract(dow from qh_tsubmit) as dow, 
count(*) cnt, 
count(*)/24 cnt_per_hr,
avg(queued_seconds) qtime, 
avg(elapsed_seconds) rtime, 
avg(qh_snippets) snips 
--avg(sn_wait_secs) sn_wait 
from nz_query_history_view 
where qh_tsubmit::date > (current_date - 365 - extract(day from current_date)) 
and (upper(qh_database) not like 'SYSTEM%' and upper(qh_database) not like 'DBA_INFO%' and upper(qh_database) not like 'HISTDB%') 
group by 1 order by 1;