--queries x day 

select qh_tsubmit::date dt, 
extract(hour from timestamp_to_localtime(qh_tsubmit)) hr,
count(*) cnt, 
avg(queued_seconds) qtime, 
avg(elapsed_seconds) rtime 
from nz_query_history_view 
where qh_tsubmit::date > (current_date - 365 - extract(day from current_date)) 
and (upper(qh_database) not like 'SYSTEM%' and upper(qh_database) not like 'DBA_INFO%' and upper(qh_database) not like 'HISTDB%') 
group by 1,2 order by 1,2;
