select timestamp_to_localtime(pp.starttime)::date dt,
extract(hour from timestamp_to_localtime(pp.starttime)) hr,
count(*) cnt,
avg(extract(epoch from pp.starttime - pp.submittime)::numeric(18,10) - extract(microseconds from pp.starttime - pp.submittime)/1000000 + extract(microseconds from pp.starttime - pp.submittime)::numeric(18,10)/1000000) qtime,
avg(extract(epoch from pe.endtime - pp.starttime)::numeric(18,10) - extract(microseconds from pe.endtime-pp.starttime)/1000000 + extract(microseconds from pe.endtime-pp.starttime)::numeric(18,10)/1000000) rtime
from "$QUERYPROLOG" qp
join "$PLANPROLOG" pp using ( npsid, npsinstanceid, opid)
join "$PLANEPILOG" pe using ( npsid, npsinstanceid, opid, planid)
where qp.submittime::date > (current_date - 365 - extract(day from current_date))
group by 1,2 order by 1,2;
